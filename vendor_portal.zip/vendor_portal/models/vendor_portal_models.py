from odoo import models, fields, api

class VendorForecast(models.Model):
    _name = 'vendor.forecast'
    _description = 'Vendor Forecast'
    _rec_name= "product_id"

    product_id = fields.Many2one('product.product', string='Product')
    expected_quantity = fields.Integer(string='Expected Quantity')
    forecast_date = fields.Date(string='Forecast Date')

class VendorAdjustmentRequest(models.Model):
    _name = 'vendor.adjustment.request'
    _description = 'Vendor Adjustment Request'
    _rec_name= "order_id"

    order_id = fields.Many2one('sale.order', string='Order Reference')
    adjustment_detail = fields.Text(string='Adjustment Detail')
    comment = fields.Text(string='Comment')

    @api.model
    def create(self, vals):
        record = super(VendorAdjustmentRequest, self).create(vals)
        template = self.env.ref('vendor_portal.email_template_adjustment_request')
        if template:
            template.send_mail(record.id, force_send=True)
        return record
