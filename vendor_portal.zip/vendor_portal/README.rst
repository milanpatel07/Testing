# Vendor Self-Service Portal for Odoo 16

The Vendor Self-Service Portal is a custom Odoo module designed for Fatmug Designs. This module enables vendors to view upcoming demand forecasts and submit order adjustment requests.

## Features

- **Forecast Viewing**: Vendors can view demand forecasts for products, showing expected quantities and forecast dates.
- **Order Adjustment Requests**: Vendors can submit adjustment requests for existing orders, which generates an automatic email notification to the procurement team.

## Prerequisites

- Odoo 16
- Basic knowledge of Odoo administration

## Installation

1. **Download or Clone the Module**: Obtain the module 'vendor_portal' from the source repository or download it as a ZIP file.

2. **Add to Addons Directory**: Place the module in your Odoo server's addons directory. This can be done by copying the 'vendor_portal' folder.

3. **Update Module List**:
   - Access your Odoo database through the web interface.
   - Go to "Apps" and remove the 'Apps' filter in the search bar.
   - Click on 'Update Apps List' and confirm.

4. **Install the Module**:
   - In the "Apps" menu, search for 'Vendor Self-Service Portal'.
   - Click 'Install' next to the module.

## Configuration

No additional configuration is needed after installation. The module uses existing Odoo features like email templates and order management.

## Usage

- **Viewing Forecasts**: Vendors can access the 'Vendor Forecast' menu item under the 'Vendor Portal' menu to view forecasts.
- **Submitting Adjustment Requests**: In the 'Vendor Adjustment' menu, vendors can submit and view their adjustment requests.

## Support

For support, bug reports, or feature requests, please contact:
- Email: support@fatmugdesigns.com
- Phone: +1 234 567 890

## License

This module is licensed under the LGPL-3.

## Author

Fatmug Designs IT Department
